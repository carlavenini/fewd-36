var mockNames = [
	"Bella",
	"Lucy",
	"Chloe",
	"Luna",
	"Sophie",
	"Lily",
	"Molly",
	"Daisy",
	"Misty",
	"Callie",
	"Max",
	"Oliver",
	"Tiger",
	"Simba",
	"Charlie",
	"Milo",
	"Spike",
	"Buddy",
	"Oscar",
	"Smokey",
	"Jack",
	"Leo"
];

var mockPictures = [
	"baby.jpg",
	"bowtie.jpg",
	"cute.jpg",
	"dog.jpg",
	"garden.jpg",
	"grumpy.jpg",
	"siamese.jpg",
	"stuffie.jpg",
	"turkey.jpg"
];